# pintos-project2
modified from https://github.com/NicoleMayer/pintos_project2

more info in my blog:https://www.dengzexuan.top/2021/05/pintos-project2/
