//
// Created by jinho on 6/2/2020.
//
#include "devices/input.h"
#ifndef THREADS_INPUT_H
#define THREADS_INPUT_H
int get_line(char* line, int max_size);

#endif //THREADS_INPUT_H
